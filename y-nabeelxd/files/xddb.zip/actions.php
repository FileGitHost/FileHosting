<?php
session_start();
require_once __DIR__ . '/includes/functions.php';

if (!isset($_SESSION['user'])) {
    redirect('index.php');
}

$host = $_SESSION['host'];
$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$port = (int)($_SESSION['port'] ?? 3306);

$conn = new mysqli($host, $user, $pass, '', $port);
if ($conn->connect_error) {
    flash_message('error', 'Connection lost: ' . $conn->connect_error);
    redirect('index.php');
}
$conn->set_charset('utf8mb4');

$action = $_POST['action'] ?? '';
$db = $_POST['db'] ?? '';
$table = $_POST['table'] ?? '';
$redirect_params = [];
if ($db) $redirect_params['db'] = $db;
if ($table) $redirect_params['table'] = $table;
if (isset($_POST['tab'])) $redirect_params['tab'] = $_POST['tab'];

function action_redirect($params) {
    redirect(base_url($params));
}

switch ($action) {
    case 'create_database':
        $name = $conn->real_escape_string(trim($_POST['db_name'] ?? ''));
        $charset = $conn->real_escape_string($_POST['charset'] ?? 'utf8mb4');
        $collation = $conn->real_escape_string($_POST['collation'] ?? 'utf8mb4_unicode_ci');
        if ($name) {
            $sql = "CREATE DATABASE `$name` CHARACTER SET $charset COLLATE $collation";
            if ($conn->query($sql)) {
                add_query_history($sql);
                flash_message('success', "Database '$name' created.");
                $redirect_params['db'] = $name;
                $redirect_params['tab'] = 'structure';
            } else {
                flash_message('error', $conn->error);
            }
        }
        break;

    case 'drop_database':
        $name = $conn->real_escape_string($db);
        if ($name && $conn->query("DROP DATABASE `$name`")) {
            add_query_history("DROP DATABASE `$name`");
            flash_message('success', "Database '$name' dropped.");
            unset($redirect_params['db'], $redirect_params['table']);
            $redirect_params['tab'] = 'databases';
        } else {
            flash_message('error', $conn->error);
        }
        break;

    case 'create_table':
        $conn->select_db($db);
        $tname = $conn->real_escape_string(trim($_POST['table_name'] ?? ''));
        $cols = $_POST['col_name'] ?? [];
        $types = $_POST['col_type'] ?? [];
        $lengths = $_POST['col_length'] ?? [];
        $nulls = $_POST['col_null'] ?? [];
        $defaults = $_POST['col_default'] ?? [];
        $extras = $_POST['col_extra'] ?? [];
        $definitions = [];
        for ($i = 0; $i < count($cols); $i++) {
            if (empty($cols[$i])) continue;
            $col = '`' . $conn->real_escape_string($cols[$i]) . '`';
            $type = strtoupper($types[$i] ?? 'VARCHAR');
            $len = $lengths[$i] ?? '';
            if (in_array($type, ['VARCHAR', 'CHAR', 'INT', 'BIGINT', 'SMALLINT', 'TINYINT', 'DECIMAL', 'FLOAT', 'DOUBLE']) && $len) {
                $col .= " $type($len)";
            } else {
                $col .= " $type";
            }
            $col .= isset($nulls[$i]) ? ' NULL' : ' NOT NULL';
            if (!empty($defaults[$i])) {
                $col .= " DEFAULT '" . $conn->real_escape_string($defaults[$i]) . "'";
            }
            if (!empty($extras[$i])) {
                $col .= ' ' . $conn->real_escape_string($extras[$i]);
            }
            $definitions[] = $col;
        }
        if ($tname && count($definitions)) {
            $sql = "CREATE TABLE `$tname` (" . implode(', ', $definitions) . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            if ($conn->query($sql)) {
                add_query_history($sql);
                flash_message('success', "Table '$tname' created.");
                $redirect_params['table'] = $tname;
                $redirect_params['tab'] = 'structure';
            } else {
                flash_message('error', $conn->error);
            }
        }
        break;

    case 'drop_table':
        $conn->select_db($db);
        if ($table && $conn->query("DROP TABLE `$table`")) {
            add_query_history("DROP TABLE `$table`");
            flash_message('success', "Table '$table' dropped.");
            unset($redirect_params['table']);
            $redirect_params['tab'] = 'structure';
        } else {
            flash_message('error', $conn->error);
        }
        break;

    case 'rename_table':
        $conn->select_db($db);
        $new_name = $conn->real_escape_string(trim($_POST['new_name'] ?? ''));
        if ($table && $new_name && $conn->query("RENAME TABLE `$table` TO `$new_name`")) {
            flash_message('success', "Table renamed to '$new_name'.");
            $redirect_params['table'] = $new_name;
        } else {
            flash_message('error', $conn->error);
        }
        break;

    case 'copy_table':
        $conn->select_db($db);
        $new_name = $conn->real_escape_string(trim($_POST['new_name'] ?? ''));
        $target_db = $conn->real_escape_string($_POST['target_db'] ?? $db);
        if ($table && $new_name) {
            $sql = "CREATE TABLE `$target_db`.`$new_name` LIKE `$db`.`$table`";
            if ($conn->query($sql)) {
                if (isset($_POST['copy_data'])) {
                    $conn->query("INSERT INTO `$target_db`.`$new_name` SELECT * FROM `$db`.`$table`");
                }
                flash_message('success', "Table copied to '$new_name'.");
            } else {
                flash_message('error', $conn->error);
            }
        }
        break;

    case 'add_column':
        $conn->select_db($db);
        $col_name = $conn->real_escape_string(trim($_POST['col_name'] ?? ''));
        $col_type = strtoupper($conn->real_escape_string($_POST['col_type'] ?? 'VARCHAR'));
        $col_length = $conn->real_escape_string($_POST['col_length'] ?? '255');
        $col_null = isset($_POST['col_null']) ? 'NULL' : 'NOT NULL';
        $col_default = $_POST['col_default'] ?? '';
        $after = $_POST['after_col'] ?? '';
        $def = "`$col_name` $col_type($col_length) $col_null";
        if ($col_default !== '') {
            $def .= " DEFAULT '" . $conn->real_escape_string($col_default) . "'";
        }
        if (!empty($_POST['col_extra'])) {
            $def .= ' ' . $conn->real_escape_string($_POST['col_extra']);
        }
        $sql = "ALTER TABLE `$table` ADD $def";
        if ($after) {
            $sql .= " AFTER `" . $conn->real_escape_string($after) . "`";
        }
        if ($conn->query($sql)) {
            add_query_history($sql);
            flash_message('success', "Column '$col_name' added.");
        } else {
            flash_message('error', $conn->error);
        }
        $redirect_params['tab'] = 'structure';
        break;

    case 'drop_column':
        $conn->select_db($db);
        $col = $conn->real_escape_string($_POST['col_name'] ?? '');
        if ($col && $conn->query("ALTER TABLE `$table` DROP COLUMN `$col`")) {
            flash_message('success', "Column '$col' dropped.");
        } else {
            flash_message('error', $conn->error);
        }
        $redirect_params['tab'] = 'structure';
        break;

    case 'insert_row':
        $conn->select_db($db);
        $fields = $_POST['fields'] ?? [];
        $cols = [];
        $vals = [];
        foreach ($fields as $col => $val) {
            $cols[] = '`' . $conn->real_escape_string($col) . '`';
            if ($val === '' && isset($_POST['nulls'][$col])) {
                $vals[] = 'NULL';
            } else {
                $vals[] = "'" . $conn->real_escape_string($val) . "'";
            }
        }
        if (count($cols)) {
            $sql = "INSERT INTO `$table` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
            if ($conn->query($sql)) {
                add_query_history($sql);
                flash_message('success', 'Row inserted successfully.');
                $redirect_params['tab'] = 'browse';
            } else {
                flash_message('error', $conn->error);
            }
        }
        break;

    case 'update_row':
        $conn->select_db($db);
        $fields = $_POST['fields'] ?? [];
        $pk_col = $_POST['pk_col'] ?? '';
        $pk_val = $_POST['pk_val'] ?? '';
        $sets = [];
        foreach ($fields as $col => $val) {
            if ($col === $pk_col) continue;
            if ($val === '' && isset($_POST['nulls'][$col])) {
                $sets[] = '`' . $conn->real_escape_string($col) . '` = NULL';
            } else {
                $sets[] = '`' . $conn->real_escape_string($col) . '` = \'' . $conn->real_escape_string($val) . '\'';
            }
        }
        if (count($sets) && $pk_col) {
            $sql = "UPDATE `$table` SET " . implode(', ', $sets) . " WHERE `" . $conn->real_escape_string($pk_col) . "` = '" . $conn->real_escape_string($pk_val) . "'";
            if ($conn->query($sql)) {
                add_query_history($sql);
                flash_message('success', 'Row updated successfully.');
            } else {
                flash_message('error', $conn->error);
            }
        }
        $redirect_params['tab'] = 'browse';
        break;

    case 'delete_row':
        $conn->select_db($db);
        $pk_col = $_POST['pk_col'] ?? '';
        $pk_val = $_POST['pk_val'] ?? '';
        if ($pk_col) {
            $sql = "DELETE FROM `$table` WHERE `" . $conn->real_escape_string($pk_col) . "` = '" . $conn->real_escape_string($pk_val) . "'";
            if ($conn->query($sql)) {
                add_query_history($sql);
                flash_message('success', 'Row deleted.');
            } else {
                flash_message('error', $conn->error);
            }
        }
        $redirect_params['tab'] = 'browse';
        break;

    case 'copy_row':
        $conn->select_db($db);
        $pk_col = $_POST['pk_col'] ?? '';
        $pk_val = $_POST['pk_val'] ?? '';
        if ($pk_col) {
            $result = $conn->query("SELECT * FROM `$table` WHERE `" . $conn->real_escape_string($pk_col) . "` = '" . $conn->real_escape_string($pk_val) . "'");
            if ($result && $row = $result->fetch_assoc()) {
                unset($row[$pk_col]);
                $cols = [];
                $vals = [];
                foreach ($row as $k => $v) {
                    $cols[] = '`' . $conn->real_escape_string($k) . '`';
                    $vals[] = $v === null ? 'NULL' : "'" . $conn->real_escape_string($v) . "'";
                }
                $sql = "INSERT INTO `$table` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
                if ($conn->query($sql)) {
                    flash_message('success', 'Row copied.');
                } else {
                    flash_message('error', $conn->error);
                }
            }
        }
        $redirect_params['tab'] = 'browse';
        break;

    case 'run_sql':
        $sql = $_POST['sql_query'] ?? '';
        if ($sql) {
            add_query_history($sql);
            $queries = array_filter(array_map('trim', explode(';', $sql)));
            $last_result = null;
            $messages = [];
            foreach ($queries as $q) {
                if ($q === '') continue;
                $res = run_query($conn, $q);
                if (!$res['success']) {
                    flash_message('error', $res['error']);
                    $_SESSION['last_sql'] = $sql;
                    action_redirect($redirect_params);
                }
                if ($res['result'] instanceof mysqli_result) {
                    $last_result = $res['result'];
                } else {
                    $messages[] = $res['affected'] . ' row(s) affected.';
                }
            }
            if ($last_result) {
                $_SESSION['sql_result'] = [];
                while ($row = $last_result->fetch_assoc()) {
                    $_SESSION['sql_result'][] = $row;
                }
                $_SESSION['sql_columns'] = [];
                $last_result->data_seek(0);
                while ($field = $last_result->fetch_field()) {
                    $_SESSION['sql_columns'][] = $field->name;
                }
            }
            if ($messages) {
                flash_message('success', implode(' ', $messages));
            } else {
                flash_message('success', 'Query executed successfully.');
            }
            $_SESSION['last_sql'] = $sql;
        }
        break;

    case 'search_table':
        $conn->select_db($db);
        $search_col = $_POST['search_col'] ?? '';
        $search_val = $_POST['search_val'] ?? '';
        $search_type = $_POST['search_type'] ?? 'like';
        if ($search_col && $search_val !== '') {
            $col = '`' . $conn->real_escape_string($search_col) . '`';
            $val = $conn->real_escape_string($search_val);
            switch ($search_type) {
                case 'exact':
                    $where = "$col = '$val'";
                    break;
                case 'begin':
                    $where = "$col LIKE '$val%'";
                    break;
                default:
                    $where = "$col LIKE '%$val%'";
            }
            $result = $conn->query("SELECT * FROM `$table` WHERE $where LIMIT 100");
            if ($result) {
                $_SESSION['search_result'] = [];
                while ($row = $result->fetch_assoc()) {
                    $_SESSION['search_result'][] = $row;
                }
                $_SESSION['search_columns'] = [];
                while ($field = $result->fetch_field()) {
                    $_SESSION['search_columns'][] = $field->name;
                }
            }
        }
        $redirect_params['tab'] = 'search';
        break;

    case 'optimize_table':
        $conn->select_db($db);
        if ($conn->query("OPTIMIZE TABLE `$table`")) {
            flash_message('success', "Table '$table' optimized.");
        } else {
            flash_message('error', $conn->error);
        }
        $redirect_params['tab'] = 'operations';
        break;

    case 'repair_table':
        $conn->select_db($db);
        if ($conn->query("REPAIR TABLE `$table`")) {
            flash_message('success', "Table '$table' repaired.");
        } else {
            flash_message('error', $conn->error);
        }
        $redirect_params['tab'] = 'operations';
        break;

    case 'check_table':
        $conn->select_db($db);
        if ($conn->query("CHECK TABLE `$table`")) {
            flash_message('success', "Table '$table' checked.");
        } else {
            flash_message('error', $conn->error);
        }
        $redirect_params['tab'] = 'operations';
        break;

    case 'analyze_table':
        $conn->select_db($db);
        if ($conn->query("ANALYZE TABLE `$table`")) {
            flash_message('success', "Table '$table' analyzed.");
        } else {
            flash_message('error', $conn->error);
        }
        $redirect_params['tab'] = 'operations';
        break;

    case 'change_engine':
        $conn->select_db($db);
        $engine = $conn->real_escape_string($_POST['engine'] ?? 'InnoDB');
        if ($conn->query("ALTER TABLE `$table` ENGINE = $engine")) {
            flash_message('success', "Engine changed to $engine.");
        } else {
            flash_message('error', $conn->error);
        }
        $redirect_params['tab'] = 'operations';
        break;

    case 'create_user':
        $new_user = $conn->real_escape_string(trim($_POST['new_user'] ?? ''));
        $new_host = $conn->real_escape_string(trim($_POST['new_host'] ?? '%'));
        $new_pass = $conn->real_escape_string(trim($_POST['new_pass'] ?? ''));
        if ($new_user && $new_pass) {
            $sql = "CREATE USER '$new_user'@'$new_host' IDENTIFIED BY '$new_pass'";
            if ($conn->query($sql)) {
                flash_message('success', "User '$new_user'@'$new_host' created.");
            } else {
                flash_message('error', $conn->error);
            }
        }
        $redirect_params['tab'] = 'users';
        break;

    case 'drop_user':
        $drop_user = $conn->real_escape_string($_POST['drop_user'] ?? '');
        $drop_host = $conn->real_escape_string($_POST['drop_host'] ?? '');
        if ($drop_user) {
            if ($conn->query("DROP USER '$drop_user'@'$drop_host'")) {
                flash_message('success', "User dropped.");
            } else {
                flash_message('error', $conn->error);
            }
        }
        $redirect_params['tab'] = 'users';
        break;

    case 'grant_privileges':
        $grant_user = $conn->real_escape_string($_POST['grant_user'] ?? '');
        $grant_host = $conn->real_escape_string($_POST['grant_host'] ?? '');
        $privileges = $_POST['privileges'] ?? [];
        $grant_db = $conn->real_escape_string($_POST['grant_db'] ?? '*');
        if ($grant_user && count($privileges)) {
            $priv_str = implode(', ', array_map(function($p) use ($conn) {
                return $conn->real_escape_string(strtoupper($p));
            }, $privileges));
            $sql = "GRANT $priv_str ON `$grant_db`.* TO '$grant_user'@'$grant_host'";
            if ($conn->query($sql)) {
                $conn->query('FLUSH PRIVILEGES');
                flash_message('success', 'Privileges granted.');
            } else {
                flash_message('error', $conn->error);
            }
        }
        $redirect_params['tab'] = 'users';
        break;

    case 'toggle_favorite':
        $fav = $_POST['fav_db'] ?? '';
        if ($fav) {
            if (in_array($fav, $_SESSION['favorites'], true)) {
                $_SESSION['favorites'] = array_values(array_diff($_SESSION['favorites'], [$fav]));
            } else {
                $_SESSION['favorites'][] = $fav;
            }
            $redirect_params['db'] = $fav;
            $redirect_params['tab'] = 'structure';
        }
        break;

    case 'remove_recent':
        $recent_db = $_POST['recent_db'] ?? '';
        if ($recent_db && in_array($recent_db, $_SESSION['recent'], true)) {
            $_SESSION['recent'] = array_values(array_diff($_SESSION['recent'], [$recent_db]));
        }
        break;

    case 'import_sql':
        $conn->select_db($db);
        $sql_content = '';
        if (!empty($_FILES['import_file']['tmp_name'])) {
            $sql_content = file_get_contents($_FILES['import_file']['tmp_name']);
        } elseif (!empty($_POST['import_text'])) {
            $sql_content = $_POST['import_text'];
        }
        if ($sql_content) {
            $queries = array_filter(array_map('trim', explode(';', $sql_content)));
            $count = 0;
            foreach ($queries as $q) {
                if ($q === '') continue;
                if ($conn->query($q)) $count++;
            }
            add_query_history("-- Import: $count queries executed");
            flash_message('success', "$count queries imported successfully.");
        }
        $redirect_params['tab'] = 'import';
        break;

    case 'add_index':
        $conn->select_db($db);
        $idx_name = $conn->real_escape_string(trim($_POST['idx_name'] ?? ''));
        $idx_col = $conn->real_escape_string(trim($_POST['idx_col'] ?? ''));
        $idx_type = $_POST['idx_type'] ?? 'INDEX';
        if ($idx_col) {
            $type_map = ['PRIMARY' => 'ADD PRIMARY KEY', 'UNIQUE' => 'ADD UNIQUE', 'FULLTEXT' => 'ADD FULLTEXT', 'INDEX' => 'ADD INDEX'];
            $add = $type_map[$idx_type] ?? 'ADD INDEX';
            $name_part = $idx_type === 'PRIMARY' ? "(`$idx_col`)" : ($idx_name ? " `$idx_name` (`$idx_col`)" : " (`$idx_col`)");
            $sql = "ALTER TABLE `$table` $add$name_part";
            if ($conn->query($sql)) {
                flash_message('success', 'Index added.');
            } else {
                flash_message('error', $conn->error);
            }
        }
        $redirect_params['tab'] = 'indexes';
        break;
}

action_redirect($redirect_params);
