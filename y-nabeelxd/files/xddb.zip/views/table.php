<?php
$conn->select_db($selected_db);
$columns = get_table_structure($conn, $selected_db, $selected_table);
$pk = get_primary_key($conn, $selected_db, $selected_table);
$page_num = max(1, (int)($_GET['page'] ?? 1));
$per_page = 25;
$offset = ($page_num - 1) * $per_page;
$edit_mode = isset($_GET['edit']) && $_GET['edit'] === '1';
$edit_pk_val = $_GET['pk_val'] ?? '';

switch ($active_tab) {
    case 'browse':
        $total = 0;
        $count_res = $conn->query("SELECT COUNT(*) as cnt FROM `$selected_table`");
        if ($count_res) $total = (int)$count_res->fetch_assoc()['cnt'];
        $result = $conn->query("SELECT * FROM `$selected_table` LIMIT $per_page OFFSET $offset");
        $rows = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) $rows[] = $row;
        }
        $col_names = !empty($rows) ? array_keys($rows[0]) : array_column($columns, 'Field');
        ?>
        <div class="panel">
          <div class="panel-header">
            Browse — <?= esc($selected_table) ?>
            <span style="font-weight:400;color:var(--text-muted)"><?= $total ?> row(s)</span>
          </div>
          <div class="panel-body" style="padding:0">
            <?php if (empty($rows)): ?>
              <p style="padding:16px;color:var(--text-muted)">No records found. <a href="<?= esc(base_url(['db' => $selected_db, 'table' => $selected_table, 'tab' => 'insert'])) ?>">Insert a row</a></p>
            <?php else: ?>
              <div class="table-wrap" style="border:none"><table class="data-table">
                <thead><tr>
                  <?php foreach ($col_names as $c): ?><th><?= esc($c) ?></th><?php endforeach; ?>
                  <th>Actions</th>
                </tr></thead>
                <tbody>
                  <?php foreach ($rows as $row): ?>
                    <tr>
                      <?php foreach ($row as $v): ?><td><?= $v === null ? '<span class="null-val">NULL</span>' : esc($v) ?></td><?php endforeach; ?>
                      <td class="row-actions">
                        <?php if ($pk): ?>
                          <a href="<?= esc(base_url(['db' => $selected_db, 'table' => $selected_table, 'tab' => 'insert', 'edit' => '1', 'pk_val' => $row[$pk]])) ?>" class="btn btn-secondary btn-sm">Edit</a>
                          <form method="POST" action="actions.php" class="inline-form">
                            <input type="hidden" name="action" value="copy_row">
                            <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
                            <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
                            <input type="hidden" name="pk_col" value="<?= esc($pk) ?>">
                            <input type="hidden" name="pk_val" value="<?= esc($row[$pk]) ?>">
                            <button type="submit" class="btn btn-secondary btn-sm">Copy</button>
                          </form>
                          <form method="POST" action="actions.php" class="inline-form confirm-delete">
                            <input type="hidden" name="action" value="delete_row">
                            <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
                            <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
                            <input type="hidden" name="pk_col" value="<?= esc($pk) ?>">
                            <input type="hidden" name="pk_val" value="<?= esc($row[$pk]) ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                          </form>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table></div>
              <div class="pagination" style="padding:12px 16px">
                <?php if ($page_num > 1): ?><a href="<?= esc(base_url(['db' => $selected_db, 'table' => $selected_table, 'tab' => 'browse', 'page' => $page_num - 1])) ?>" class="btn btn-secondary btn-sm">← Previous</a><?php endif; ?>
                Page <?= $page_num ?> of <?= max(1, ceil($total / $per_page)) ?>
                <?php if ($offset + $per_page < $total): ?><a href="<?= esc(base_url(['db' => $selected_db, 'table' => $selected_table, 'tab' => 'browse', 'page' => $page_num + 1])) ?>" class="btn btn-secondary btn-sm">Next →</a><?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'structure':
        $indexes = get_table_indexes($conn, $selected_db, $selected_table);
        $status = get_table_status($conn, $selected_db, $selected_table);
        ?>
        <div class="stats-grid">
          <div class="stat-card"><div class="stat-label">Rows</div><div class="stat-value"><?= esc($status['Rows'] ?? 0) ?></div></div>
          <div class="stat-card"><div class="stat-label">Engine</div><div class="stat-value" style="font-size:14px"><?= esc($status['Engine'] ?? '') ?></div></div>
          <div class="stat-card"><div class="stat-label">Collation</div><div class="stat-value" style="font-size:14px"><?= esc($status['Collation'] ?? '') ?></div></div>
          <div class="stat-card"><div class="stat-label">Size</div><div class="stat-value" style="font-size:14px"><?= format_bytes(($status['Data_length'] ?? 0) + ($status['Index_length'] ?? 0)) ?></div></div>
        </div>
        <div class="panel">
          <div class="panel-header">Table Structure — <?= esc($selected_table) ?></div>
          <div class="panel-body" style="padding:0">
            <div class="table-wrap" style="border:none"><table class="data-table">
              <thead><tr><th>#</th><th>Column</th><th>Type</th><th>Collation</th><th>Null</th><th>Default</th><th>Extra</th><th>Actions</th></tr></thead>
              <tbody>
                <?php foreach ($columns as $i => $col): ?>
                <tr>
                  <td><?= $i + 1 ?></td>
                  <td><strong><?= esc($col['Field']) ?></strong><?= $col['Key'] === 'PRI' ? ' 🔑' : '' ?></td>
                  <td><?= esc($col['Type']) ?></td>
                  <td><?= esc($col['Collation'] ?? '') ?></td>
                  <td><?= esc($col['Null']) ?></td>
                  <td><?= $col['Default'] === null ? '<span class="null-val">NULL</span>' : esc($col['Default']) ?></td>
                  <td><?= esc($col['Extra']) ?></td>
                  <td>
                    <form method="POST" action="actions.php" class="inline-form confirm-delete">
                      <input type="hidden" name="action" value="drop_column">
                      <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
                      <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
                      <input type="hidden" name="col_name" value="<?= esc($col['Field']) ?>">
                      <button type="submit" class="btn btn-danger btn-sm">Drop</button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table></div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-header">Add Column</div>
          <div class="panel-body">
            <form method="POST" action="actions.php">
              <input type="hidden" name="action" value="add_column">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <div class="form-row">
                <div class="form-group"><label class="form-label">Name</label><input type="text" name="col_name" class="form-input" required></div>
                <div class="form-group"><label class="form-label">Type</label><select name="col_type" class="form-select"><option>VARCHAR</option><option>INT</option><option>BIGINT</option><option>TEXT</option><option>DATE</option><option>DATETIME</option><option>FLOAT</option><option>DECIMAL</option><option>BOOLEAN</option></select></div>
                <div class="form-group"><label class="form-label">Length</label><input type="text" name="col_length" class="form-input" value="255"></div>
                <div class="form-group"><label class="form-label">Default</label><input type="text" name="col_default" class="form-input"></div>
                <div class="form-group"><label class="form-label">After</label><select name="after_col" class="form-select"><option value="">First</option><?php foreach ($columns as $c): ?><option value="<?= esc($c['Field']) ?>"><?= esc($c['Field']) ?></option><?php endforeach; ?></select></div>
              </div>
              <label class="checkbox-label"><input type="checkbox" name="col_null" checked> Allow NULL</label>
              <div class="form-group" style="margin-top:8px"><label class="form-label">Extra</label><input type="text" name="col_extra" class="form-input" placeholder="AUTO_INCREMENT"></div>
              <div class="form-actions"><button type="submit" class="btn btn-primary">Add Column</button></div>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'sql':
        $last_sql = $_SESSION['last_sql'] ?? "SELECT * FROM `$selected_table` LIMIT 25;";
        ?>
        <div class="panel">
          <div class="panel-header">SQL — <?= esc($selected_table) ?></div>
          <div class="panel-body">
            <form method="POST" action="actions.php">
              <input type="hidden" name="action" value="run_sql">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <input type="hidden" name="tab" value="sql">
              <textarea name="sql_query" class="form-textarea" rows="8"><?= esc($last_sql) ?></textarea>
              <div class="form-actions"><button type="submit" class="btn btn-primary">Go</button></div>
            </form>
            <?php if (!empty($_SESSION['sql_result'])): ?>
              <div style="margin-top:16px"><div class="table-wrap"><table class="data-table"><thead><tr>
                <?php foreach ($_SESSION['sql_columns'] as $col): ?><th><?= esc($col) ?></th><?php endforeach; ?>
              </tr></thead><tbody>
                <?php foreach ($_SESSION['sql_result'] as $row): ?><tr><?php foreach ($row as $v): ?><td><?= $v === null ? '<span class="null-val">NULL</span>' : esc($v) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
              </tbody></table></div></div>
              <?php unset($_SESSION['sql_result'], $_SESSION['sql_columns']); ?>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'search':
        ?>
        <div class="panel">
          <div class="panel-header">Search — <?= esc($selected_table) ?></div>
          <div class="panel-body">
            <form method="POST" action="actions.php">
              <input type="hidden" name="action" value="search_table">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <div class="form-row">
                <div class="form-group"><label class="form-label">Column</label><select name="search_col" class="form-select" required><?php foreach ($columns as $c): ?><option value="<?= esc($c['Field']) ?>"><?= esc($c['Field']) ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label class="form-label">Value</label><input type="text" name="search_val" class="form-input" required></div>
                <div class="form-group"><label class="form-label">Type</label><select name="search_type" class="form-select"><option value="like">Contains</option><option value="exact">Exact</option><option value="begin">Starts with</option></select></div>
              </div>
              <button type="submit" class="btn btn-primary">Search</button>
            </form>
            <?php if (!empty($_SESSION['search_result'])): ?>
              <div style="margin-top:16px"><div class="table-wrap"><table class="data-table"><thead><tr>
                <?php foreach ($_SESSION['search_columns'] as $col): ?><th><?= esc($col) ?></th><?php endforeach; ?>
              </tr></thead><tbody>
                <?php foreach ($_SESSION['search_result'] as $row): ?><tr><?php foreach ($row as $v): ?><td><?= $v === null ? '<span class="null-val">NULL</span>' : esc($v) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
              </tbody></table></div></div>
              <?php unset($_SESSION['search_result'], $_SESSION['search_columns']); ?>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'insert':
        $edit_row = null;
        if ($edit_mode && $pk && $edit_pk_val) {
            $res = $conn->query("SELECT * FROM `$selected_table` WHERE `" . $conn->real_escape_string($pk) . "` = '" . $conn->real_escape_string($edit_pk_val) . "'");
            if ($res) $edit_row = $res->fetch_assoc();
        }
        $is_edit = $edit_row !== null;
        ?>
        <div class="panel">
          <div class="panel-header"><?= $is_edit ? 'Edit Row' : 'Insert Row' ?> — <?= esc($selected_table) ?></div>
          <div class="panel-body">
            <form method="POST" action="actions.php">
              <input type="hidden" name="action" value="<?= $is_edit ? 'update_row' : 'insert_row' ?>">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <?php if ($is_edit): ?>
                <input type="hidden" name="pk_col" value="<?= esc($pk) ?>">
                <input type="hidden" name="pk_val" value="<?= esc($edit_pk_val) ?>">
              <?php endif; ?>
              <div class="table-wrap"><table class="data-table">
                <thead><tr><th>Column</th><th>Type</th><th>Null</th><th>Value</th></tr></thead>
                <tbody>
                  <?php foreach ($columns as $col):
                    $field = $col['Field'];
                    $is_pk = ($field === $pk);
                    if ($is_edit && $is_pk && strpos($col['Extra'], 'auto_increment') !== false) continue;
                    $val = $is_edit ? ($edit_row[$field] ?? '') : '';
                  ?>
                  <tr>
                    <td><strong><?= esc($field) ?></strong></td>
                    <td><?= esc($col['Type']) ?></td>
                    <td><?= esc($col['Null']) ?></td>
                    <td>
                      <?php if (stripos($col['Type'], 'text') !== false): ?>
                        <textarea name="fields[<?= esc($field) ?>]" class="form-textarea" rows="2"><?= esc($val) ?></textarea>
                      <?php else: ?>
                        <input type="text" name="fields[<?= esc($field) ?>]" class="form-input" value="<?= esc($val) ?>">
                      <?php endif; ?>
                      <?php if ($col['Null'] === 'YES'): ?>
                        <label class="checkbox-label" style="margin-top:4px"><input type="checkbox" name="nulls[<?= esc($field) ?>]"> NULL</label>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table></div>
              <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $is_edit ? 'Save' : 'Insert' ?></button>
                <?php if ($is_edit): ?><a href="<?= esc(base_url(['db' => $selected_db, 'table' => $selected_table, 'tab' => 'browse'])) ?>" class="btn btn-secondary">Cancel</a><?php endif; ?>
              </div>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'export':
        ?>
        <div class="panel">
          <div class="panel-header">Export — <?= esc($selected_table) ?></div>
          <div class="panel-body">
            <p style="margin-bottom:12px;color:var(--text-secondary)">Choose export format:</p>
            <div class="form-actions">
              <a href="export.php?db=<?= urlencode($selected_db) ?>&table=<?= urlencode($selected_table) ?>&format=sql" class="btn btn-primary">SQL</a>
              <a href="export.php?db=<?= urlencode($selected_db) ?>&table=<?= urlencode($selected_table) ?>&format=csv" class="btn btn-secondary">CSV</a>
              <a href="export.php?db=<?= urlencode($selected_db) ?>&table=<?= urlencode($selected_table) ?>&format=json" class="btn btn-secondary">JSON</a>
              <a href="export.php?db=<?= urlencode($selected_db) ?>&table=<?= urlencode($selected_table) ?>&format=xml" class="btn btn-secondary">XML</a>
            </div>
          </div>
        </div>
        <?php
        break;

    case 'import':
        ?>
        <div class="panel">
          <div class="panel-header">Import — <?= esc($selected_table) ?></div>
          <div class="panel-body">
            <form method="POST" action="actions.php" enctype="multipart/form-data">
              <input type="hidden" name="action" value="import_sql">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="tab" value="import">
              <div class="form-group"><label class="form-label">File</label><input type="file" name="import_file" class="form-input" accept=".sql,.csv"></div>
              <div class="form-group"><label class="form-label">SQL</label><textarea name="import_text" class="form-textarea" rows="6"></textarea></div>
              <button type="submit" class="btn btn-primary">Import</button>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'operations':
        $status = get_table_status($conn, $selected_db, $selected_table);
        ?>
        <div class="panel">
          <div class="panel-header">Table Operations — <?= esc($selected_table) ?></div>
          <div class="panel-body">
            <form method="POST" action="actions.php" style="margin-bottom:16px">
              <input type="hidden" name="action" value="rename_table">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <div class="form-group"><label class="form-label">Rename Table</label><div style="display:flex;gap:8px"><input type="text" name="new_name" class="form-input" placeholder="New table name" required><button type="submit" class="btn btn-primary">Rename</button></div></div>
            </form>
            <form method="POST" action="actions.php" style="margin-bottom:16px">
              <input type="hidden" name="action" value="copy_table">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <div class="form-row">
                <div class="form-group"><label class="form-label">Copy To</label><input type="text" name="new_name" class="form-input" required></div>
                <div class="form-group"><label class="form-label">Target Database</label><select name="target_db" class="form-select"><?php foreach ($databases as $dbitem): ?><option value="<?= esc($dbitem) ?>" <?= $dbitem === $selected_db ? 'selected' : '' ?>><?= esc($dbitem) ?></option><?php endforeach; ?></select></div>
              </div>
              <label class="checkbox-label"><input type="checkbox" name="copy_data" checked> Copy data</label>
              <div class="form-actions"><button type="submit" class="btn btn-secondary">Copy Table</button></div>
            </form>
            <form method="POST" action="actions.php" style="margin-bottom:16px">
              <input type="hidden" name="action" value="change_engine">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <div class="form-group"><label class="form-label">Storage Engine (current: <?= esc($status['Engine'] ?? '') ?>)</label>
                <div style="display:flex;gap:8px"><select name="engine" class="form-select"><option value="InnoDB">InnoDB</option><option value="MyISAM">MyISAM</option><option value="MEMORY">MEMORY</option></select><button type="submit" class="btn btn-secondary">Change</button></div>
              </div>
            </form>
            <div class="form-actions">
              <form method="POST" action="actions.php" class="inline-form"><input type="hidden" name="action" value="check_table"><input type="hidden" name="db" value="<?= esc($selected_db) ?>"><input type="hidden" name="table" value="<?= esc($selected_table) ?>"><button type="submit" class="btn btn-secondary">Check</button></form>
              <form method="POST" action="actions.php" class="inline-form"><input type="hidden" name="action" value="optimize_table"><input type="hidden" name="db" value="<?= esc($selected_db) ?>"><input type="hidden" name="table" value="<?= esc($selected_table) ?>"><button type="submit" class="btn btn-secondary">Optimize</button></form>
              <form method="POST" action="actions.php" class="inline-form"><input type="hidden" name="action" value="analyze_table"><input type="hidden" name="db" value="<?= esc($selected_db) ?>"><input type="hidden" name="table" value="<?= esc($selected_table) ?>"><button type="submit" class="btn btn-secondary">Analyze</button></form>
              <form method="POST" action="actions.php" class="inline-form"><input type="hidden" name="action" value="repair_table"><input type="hidden" name="db" value="<?= esc($selected_db) ?>"><input type="hidden" name="table" value="<?= esc($selected_table) ?>"><button type="submit" class="btn btn-secondary">Repair</button></form>
            </div>
            <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
            <form method="POST" action="actions.php" class="confirm-delete">
              <input type="hidden" name="action" value="drop_table">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <button type="submit" class="btn btn-danger">Drop Table</button>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'triggers':
        $triggers = get_triggers($conn, $selected_db, $selected_table);
        ?>
        <div class="panel">
          <div class="panel-header">Triggers — <?= esc($selected_table) ?></div>
          <div class="panel-body" style="padding:0">
            <?php if (empty($triggers)): ?>
              <p style="padding:16px;color:var(--text-muted)">No triggers on this table.</p>
            <?php else: ?>
              <div class="table-wrap" style="border:none"><table class="data-table">
                <thead><tr><th>Trigger</th><th>Event</th><th>Timing</th><th>Statement</th></tr></thead>
                <tbody><?php foreach ($triggers as $t): ?>
                  <tr><td><?= esc($t['Trigger']) ?></td><td><?= esc($t['Event']) ?></td><td><?= esc($t['Timing']) ?></td><td style="font-size:11px"><?= esc($t['Statement'] ?? '') ?></td></tr>
                <?php endforeach; ?></tbody>
              </table></div>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'indexes':
        $indexes = get_table_indexes($conn, $selected_db, $selected_table);
        $grouped = [];
        foreach ($indexes as $idx) {
            $grouped[$idx['Key_name']][] = $idx;
        }
        ?>
        <div class="panel">
          <div class="panel-header">Indexes — <?= esc($selected_table) ?></div>
          <div class="panel-body" style="padding:0">
            <div class="table-wrap" style="border:none"><table class="data-table">
              <thead><tr><th>Key Name</th><th>Type</th><th>Unique</th><th>Column</th><th>Cardinality</th></tr></thead>
              <tbody>
                <?php foreach ($indexes as $idx): ?>
                <tr>
                  <td><?= esc($idx['Key_name']) ?></td>
                  <td><?= $idx['Key_name'] === 'PRIMARY' ? 'PRIMARY' : ($idx['Index_type'] ?? 'INDEX') ?></td>
                  <td><?= $idx['Non_unique'] == 0 ? 'Yes' : 'No' ?></td>
                  <td><?= esc($idx['Column_name']) ?></td>
                  <td><?= esc($idx['Cardinality'] ?? '') ?></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table></div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-header">Add Index</div>
          <div class="panel-body">
            <form method="POST" action="actions.php">
              <input type="hidden" name="action" value="add_index">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="table" value="<?= esc($selected_table) ?>">
              <div class="form-row">
                <div class="form-group"><label class="form-label">Index Name</label><input type="text" name="idx_name" class="form-input"></div>
                <div class="form-group"><label class="form-label">Column</label><select name="idx_col" class="form-select" required><?php foreach ($columns as $c): ?><option value="<?= esc($c['Field']) ?>"><?= esc($c['Field']) ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label class="form-label">Type</label><select name="idx_type" class="form-select"><option value="INDEX">Index</option><option value="UNIQUE">Unique</option><option value="FULLTEXT">Fulltext</option><option value="PRIMARY">Primary</option></select></div>
              </div>
              <button type="submit" class="btn btn-primary">Create Index</button>
            </form>
          </div>
        </div>
        <?php
        break;
}
