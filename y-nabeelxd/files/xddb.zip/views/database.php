<?php
$conn->select_db($selected_db);
switch ($active_tab) {
    case 'structure':
        $views = get_views($conn, $selected_db);
        ?>
        <div class="stats-grid">
          <div class="stat-card"><div class="stat-label">Database</div><div class="stat-value" style="font-size:14px"><?= esc($selected_db) ?></div></div>
          <div class="stat-card"><div class="stat-label">Tables</div><div class="stat-value"><?= count($tables) ?></div></div>
          <div class="stat-card"><div class="stat-label">Size</div><div class="stat-value" style="font-size:14px"><?= format_bytes(get_db_size($conn, $selected_db)) ?></div></div>
        </div>
        <div class="panel">
          <div class="panel-header">Create Table</div>
          <div class="panel-body">
            <form method="POST" action="actions.php">
              <input type="hidden" name="action" value="create_table">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <div class="form-group"><label class="form-label">Table Name</label><input type="text" name="table_name" class="form-input" required></div>
              <div class="table-wrap"><table class="data-table">
                <thead><tr><th>Column</th><th>Type</th><th>Length</th><th>Null</th><th>Default</th><th>Extra</th></tr></thead>
                <tbody>
                  <?php for ($i = 0; $i < 3; $i++): ?>
                  <tr>
                    <td><input type="text" name="col_name[]" class="form-input" <?= $i === 0 ? 'value="id"' : '' ?>></td>
                    <td><select name="col_type[]" class="form-select"><option>VARCHAR</option><option>INT</option><option>BIGINT</option><option>TEXT</option><option>DATE</option><option>DATETIME</option><option>FLOAT</option><option>BOOLEAN</option><option>DECIMAL</option></select></td>
                    <td><input type="text" name="col_length[]" class="form-input" value="<?= $i === 0 ? '11' : '255' ?>"></td>
                    <td><input type="checkbox" name="col_null[<?= $i ?>]" <?= $i === 0 ? '' : 'checked' ?>></td>
                    <td><input type="text" name="col_default[]" class="form-input"></td>
                    <td><input type="text" name="col_extra[]" class="form-input" <?= $i === 0 ? 'value="AUTO_INCREMENT PRIMARY KEY"' : '' ?>></td>
                  </tr>
                  <?php endfor; ?>
                </tbody>
              </table></div>
              <div class="form-actions"><button type="submit" class="btn btn-primary">Create Table</button></div>
            </form>
          </div>
        </div>
        <div class="panel">
          <div class="panel-header">Tables</div>
          <div class="panel-body" style="padding:0">
            <div class="table-wrap" style="border:none"><table class="data-table">
              <thead><tr><th>Table</th><th>Rows</th><th>Type</th><th>Size</th><th>Collation</th><th>Actions</th></tr></thead>
              <tbody>
                <?php foreach ($tables as $titem):
                  $status = get_table_status($conn, $selected_db, $titem);
                ?>
                <tr>
                  <td><a href="<?= esc(base_url(['db' => $selected_db, 'table' => $titem, 'tab' => 'browse'])) ?>"><?= esc($titem) ?></a></td>
                  <td><?= esc($status['Rows'] ?? '0') ?></td>
                  <td><?= esc($status['Engine'] ?? '') ?></td>
                  <td><?= format_bytes(($status['Data_length'] ?? 0) + ($status['Index_length'] ?? 0)) ?></td>
                  <td><?= esc($status['Collation'] ?? '') ?></td>
                  <td class="row-actions">
                    <a href="<?= esc(base_url(['db' => $selected_db, 'table' => $titem, 'tab' => 'browse'])) ?>" class="btn btn-secondary btn-sm">Browse</a>
                    <form method="POST" action="actions.php" class="inline-form confirm-delete">
                      <input type="hidden" name="action" value="drop_table">
                      <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
                      <input type="hidden" name="table" value="<?= esc($titem) ?>">
                      <button type="submit" class="btn btn-danger btn-sm">Drop</button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table></div>
          </div>
        </div>
        <?php if (!empty($views)): ?>
        <div class="panel">
          <div class="panel-header">Views</div>
          <div class="panel-body" style="padding:0">
            <div class="table-wrap" style="border:none"><table class="data-table">
              <thead><tr><th>View</th></tr></thead>
              <tbody><?php foreach ($views as $v): ?><tr><td><?= esc($v) ?></td></tr><?php endforeach; ?></tbody>
            </table></div>
          </div>
        </div>
        <?php endif; ?>
        <div class="panel">
          <div class="panel-header">Database Operations</div>
          <div class="panel-body">
            <form method="POST" action="actions.php" class="confirm-delete inline-form">
              <input type="hidden" name="action" value="drop_database">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <button type="submit" class="btn btn-danger">Drop Database</button>
            </form>
            <form method="POST" action="actions.php" class="inline-form" style="margin-left:8px">
              <input type="hidden" name="action" value="toggle_favorite">
              <input type="hidden" name="fav_db" value="<?= esc($selected_db) ?>">
              <button type="submit" class="btn btn-secondary"><?= in_array($selected_db, $_SESSION['favorites'], true) ? 'Remove from Favorites' : 'Add to Favorites' ?></button>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'sql':
        $last_sql = $_SESSION['last_sql'] ?? "USE `$selected_db`;\n";
        ?>
        <div class="panel">
          <div class="panel-header">SQL — <?= esc($selected_db) ?></div>
          <div class="panel-body">
            <form method="POST" action="actions.php">
              <input type="hidden" name="action" value="run_sql">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="tab" value="sql">
              <textarea name="sql_query" class="form-textarea" rows="8"><?= esc($last_sql) ?></textarea>
              <div class="form-actions"><button type="submit" class="btn btn-primary">Go</button></div>
            </form>
            <?php if (!empty($_SESSION['sql_result'])): ?>
              <div style="margin-top:16px"><div class="table-wrap"><table class="data-table"><thead><tr>
                <?php foreach ($_SESSION['sql_columns'] as $col): ?><th><?= esc($col) ?></th><?php endforeach; ?>
              </tr></thead><tbody>
                <?php foreach ($_SESSION['sql_result'] as $row): ?><tr><?php foreach ($row as $v): ?><td><?= $v === null ? '<span class="null-val">NULL</span>' : esc($v) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
              </tbody></table></div></div>
              <?php unset($_SESSION['sql_result'], $_SESSION['sql_columns']); ?>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'search':
        ?>
        <div class="panel">
          <div class="panel-header">Search Database</div>
          <div class="panel-body">
            <p style="color:var(--text-secondary);margin-bottom:12px">Select a table from the sidebar and use the Search tab to search within it.</p>
            <div class="table-wrap"><table class="data-table">
              <thead><tr><th>Table</th><th>Action</th></tr></thead>
              <tbody><?php foreach ($tables as $titem): ?>
                <tr><td><?= esc($titem) ?></td><td><a href="<?= esc(base_url(['db' => $selected_db, 'table' => $titem, 'tab' => 'search'])) ?>" class="btn btn-secondary btn-sm">Search</a></td></tr>
              <?php endforeach; ?></tbody>
            </table></div>
          </div>
        </div>
        <?php
        break;

    case 'export':
        ?>
        <div class="panel">
          <div class="panel-header">Export Database — <?= esc($selected_db) ?></div>
          <div class="panel-body">
            <h4 style="margin-bottom:8px">Quick Export</h4>
            <a href="export.php?db=<?= urlencode($selected_db) ?>" class="btn btn-primary">Export as SQL</a>
            <h4 style="margin:16px 0 8px">Custom Export</h4>
            <form method="GET" action="export.php">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="type" value="custom">
              <div class="form-group"><label class="form-label">Select Tables (comma separated, empty = all)</label><input type="text" name="tables" class="form-input" placeholder="<?= esc(implode(',', $tables)) ?>"></div>
              <button type="submit" class="btn btn-secondary">Custom Export</button>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'import':
        ?>
        <div class="panel">
          <div class="panel-header">Import — <?= esc($selected_db) ?></div>
          <div class="panel-body">
            <form method="POST" action="actions.php" enctype="multipart/form-data">
              <input type="hidden" name="action" value="import_sql">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <input type="hidden" name="tab" value="import">
              <div class="form-group"><label class="form-label">File</label><input type="file" name="import_file" class="form-input" accept=".sql,.zip,.gz,.csv"></div>
              <div class="form-group"><label class="form-label">SQL Text</label><textarea name="import_text" class="form-textarea" rows="6"></textarea></div>
              <button type="submit" class="btn btn-primary">Import</button>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'operations':
        ?>
        <div class="panel">
          <div class="panel-header">Database Operations</div>
          <div class="panel-body">
            <form method="POST" action="actions.php" class="confirm-delete">
              <input type="hidden" name="action" value="drop_database">
              <input type="hidden" name="db" value="<?= esc($selected_db) ?>">
              <button type="submit" class="btn btn-danger">Drop Database</button>
            </form>
          </div>
        </div>
        <?php
        break;

    case 'routines':
        $routines = get_routines($conn, $selected_db);
        ?>
        <div class="panel">
          <div class="panel-header">Routines — Stored Procedures & Functions</div>
          <div class="panel-body" style="padding:0">
            <?php if (empty($routines)): ?>
              <p style="padding:16px;color:var(--text-muted)">No routines found.</p>
            <?php else: ?>
              <div class="table-wrap" style="border:none"><table class="data-table">
                <thead><tr><th>Name</th><th>Type</th><th>Returns</th></tr></thead>
                <tbody><?php foreach ($routines as $r): ?>
                  <tr><td><?= esc($r['ROUTINE_NAME']) ?></td><td><?= esc($r['ROUTINE_TYPE']) ?></td><td><?= esc($r['DTD_IDENTIFIER'] ?? '') ?></td></tr>
                <?php endforeach; ?></tbody>
              </table></div>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'events':
        $events = get_events($conn, $selected_db);
        ?>
        <div class="panel">
          <div class="panel-header">Events — Scheduled Tasks</div>
          <div class="panel-body" style="padding:0">
            <?php if (empty($events)): ?>
              <p style="padding:16px;color:var(--text-muted)">No events found.</p>
            <?php else: ?>
              <div class="table-wrap" style="border:none"><table class="data-table">
                <thead><tr><th>Name</th><th>Status</th><th>Type</th><th>Execute At</th><th>Interval</th></tr></thead>
                <tbody><?php foreach ($events as $e): ?>
                  <tr><td><?= esc($e['Name']) ?></td><td><?= esc($e['Status']) ?></td><td><?= esc($e['Event_type']) ?></td><td><?= esc($e['Execute_at'] ?? '') ?></td><td><?= esc($e['Interval_value'] ?? '') ?> <?= esc($e['Interval_field'] ?? '') ?></td></tr>
                <?php endforeach; ?></tbody>
              </table></div>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'triggers':
        $triggers = get_triggers($conn, $selected_db);
        ?>
        <div class="panel">
          <div class="panel-header">Triggers</div>
          <div class="panel-body" style="padding:0">
            <?php if (empty($triggers)): ?>
              <p style="padding:16px;color:var(--text-muted)">No triggers found.</p>
            <?php else: ?>
              <div class="table-wrap" style="border:none"><table class="data-table">
                <thead><tr><th>Trigger</th><th>Event</th><th>Table</th><th>Timing</th></tr></thead>
                <tbody><?php foreach ($triggers as $t): ?>
                  <tr><td><?= esc($t['Trigger']) ?></td><td><?= esc($t['Event']) ?></td><td><?= esc($t['Table']) ?></td><td><?= esc($t['Timing']) ?></td></tr>
                <?php endforeach; ?></tbody>
              </table></div>
            <?php endif; ?>
          </div>
        </div>
        <?php
        break;

    case 'designer':
        ?>
        <div class="panel">
          <div class="panel-header">Designer — Visual Database Map</div>
          <div class="panel-body">
            <div class="designer-grid">
              <?php foreach ($tables as $titem):
                $cols = get_table_structure($conn, $selected_db, $titem);
              ?>
              <div class="designer-table">
                <div class="designer-table-name"><?= esc($titem) ?></div>
                <?php foreach ($cols as $c): ?>
                  <div class="designer-col"><span><?= esc($c['Field']) ?></span><span class="col-type"><?= esc($c['Type']) ?></span></div>
                <?php endforeach; ?>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
        <?php
        break;
}
