<div class="guide-overlay" id="guideOverlay" hidden>
  <div class="guide-modal" role="dialog" aria-labelledby="guideTitle" aria-modal="true">
    <div class="guide-modal-header">
      <h2 id="guideTitle">MySQL / MariaDB SQL Reference Guide</h2>
      <button type="button" class="btn-icon guide-close-btn" id="closeGuideBtn" title="Close guide">✕</button>
    </div>
    <div class="guide-modal-body">
      <p class="guide-intro">A complete SQL reference from beginner to advanced — the most important MySQL/MariaDB commands with explanations and examples.</p>

      <section class="guide-section">
        <h3>SQL Basics</h3>
        <p><strong>SQL</strong> = Structured Query Language. Used for creating databases, tables, storing/reading/updating/deleting data, managing users, permissions, backups, and optimization.</p>
      </section>

      <section class="guide-section">
        <h3>Database Commands</h3>
        <div class="guide-block">
          <h4>Show All Databases</h4>
          <pre><code>SHOW DATABASES;</code></pre>
          <p>Displays all databases.</p>
        </div>
        <div class="guide-block">
          <h4>Create Database</h4>
          <pre><code>CREATE DATABASE nabeel;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Create Database If Not Exists</h4>
          <pre><code>CREATE DATABASE IF NOT EXISTS nabeel;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Delete Database</h4>
          <pre><code>DROP DATABASE nabeel;</code></pre>
          <p class="guide-warn">⚠ All tables and data will be removed.</p>
        </div>
        <div class="guide-block">
          <h4>Select Database</h4>
          <pre><code>USE nabeel;</code></pre>
        </div>
      </section>

      <section class="guide-section">
        <h3>Table Commands</h3>
        <div class="guide-block">
          <h4>Show Tables</h4>
          <pre><code>SHOW TABLES;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Create Table</h4>
          <pre><code>CREATE TABLE users (
    id INT,
    name VARCHAR(255)
);</code></pre>
        </div>
        <div class="guide-block">
          <h4>Create Advanced Table</h4>
          <pre><code>CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    age INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);</code></pre>
        </div>
        <div class="guide-block">
          <h4>Show Table Structure</h4>
          <pre><code>DESCRIBE users;
-- or
DESC users;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Show Create Table</h4>
          <pre><code>SHOW CREATE TABLE users;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Rename Table</h4>
          <pre><code>RENAME TABLE users TO members;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Delete Table</h4>
          <pre><code>DROP TABLE users;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Delete Multiple Tables</h4>
          <pre><code>DROP TABLE users, products, orders;</code></pre>
        </div>
        <div class="guide-block">
          <h4>Empty Table</h4>
          <pre><code>TRUNCATE TABLE users;</code></pre>
          <p>Deletes all rows but keeps structure.</p>
        </div>
      </section>

      <section class="guide-section">
        <h3>Column Commands</h3>
        <div class="guide-block"><h4>Add Column</h4><pre><code>ALTER TABLE users
ADD phone VARCHAR(20);</code></pre></div>
        <div class="guide-block"><h4>Add Multiple Columns</h4><pre><code>ALTER TABLE users
ADD phone VARCHAR(20),
ADD address TEXT;</code></pre></div>
        <div class="guide-block"><h4>Rename Column</h4><pre><code>ALTER TABLE users
RENAME COLUMN phone TO mobile;</code></pre></div>
        <div class="guide-block"><h4>Modify Column</h4><pre><code>ALTER TABLE users
MODIFY mobile VARCHAR(50);</code></pre></div>
        <div class="guide-block"><h4>Delete Column</h4><pre><code>ALTER TABLE users
DROP COLUMN mobile;</code></pre></div>
      </section>

      <section class="guide-section">
        <h3>Data Commands</h3>
        <div class="guide-block"><h4>Insert Data</h4><pre><code>INSERT INTO users(name)
VALUES('Nabeel');</code></pre></div>
        <div class="guide-block"><h4>Insert Multiple Rows</h4><pre><code>INSERT INTO users(name)
VALUES
('Nabeel'),
('Alex'),
('John');</code></pre></div>
        <div class="guide-block"><h4>View Data</h4><pre><code>SELECT * FROM users;</code></pre></div>
        <div class="guide-block"><h4>View Specific Columns</h4><pre><code>SELECT id, name
FROM users;</code></pre></div>
        <div class="guide-block"><h4>Update Data</h4><pre><code>UPDATE users
SET name='Muhammed Nabeel'
WHERE id=1;</code></pre></div>
        <div class="guide-block"><h4>Delete Data</h4><pre><code>DELETE FROM users
WHERE id=1;</code></pre></div>
      </section>

      <section class="guide-section">
        <h3>Conditions</h3>
        <div class="guide-block"><h4>WHERE</h4><pre><code>SELECT * FROM users
WHERE age = 20;</code></pre></div>
        <div class="guide-block"><h4>AND</h4><pre><code>SELECT * FROM users
WHERE age = 20
AND city='Delhi';</code></pre></div>
        <div class="guide-block"><h4>OR</h4><pre><code>SELECT * FROM users
WHERE city='Delhi'
OR city='Mumbai';</code></pre></div>
        <div class="guide-block"><h4>NOT</h4><pre><code>SELECT * FROM users
WHERE NOT age=20;</code></pre></div>
      </section>

      <section class="guide-section">
        <h3>Comparison Operators</h3>
        <pre><code>=  !=  &lt;&gt;  &gt;  &lt;  &gt;=  &lt;=</code></pre>
        <pre><code>SELECT * FROM users
WHERE age > 18;</code></pre>
      </section>

      <section class="guide-section">
        <h3>LIKE — Search Text</h3>
        <pre><code>SELECT * FROM users
WHERE name LIKE '%Nabeel%';</code></pre>
        <p><code>%</code> = anything · Starts with: <code>LIKE 'Na%'</code> · Ends with: <code>LIKE '%el'</code></p>
      </section>

      <section class="guide-section">
        <h3>Sorting</h3>
        <pre><code>SELECT * FROM users ORDER BY age ASC;
SELECT * FROM users ORDER BY age DESC;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Limit Results</h3>
        <pre><code>SELECT * FROM users LIMIT 10;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Aggregate Functions</h3>
        <pre><code>SELECT COUNT(*) FROM users;
SELECT MAX(age) FROM users;
SELECT MIN(age) FROM users;
SELECT AVG(age) FROM users;
SELECT SUM(balance) FROM users;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Distinct</h3>
        <pre><code>SELECT DISTINCT city FROM users;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Group By &amp; Having</h3>
        <pre><code>SELECT city, COUNT(*)
FROM users
GROUP BY city;

SELECT city, COUNT(*)
FROM users
GROUP BY city
HAVING COUNT(*) > 5;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Joins</h3>
        <div class="guide-block"><h4>INNER JOIN</h4><pre><code>SELECT *
FROM users
INNER JOIN orders
ON users.id=orders.user_id;</code></pre></div>
        <div class="guide-block"><h4>LEFT JOIN</h4><pre><code>SELECT *
FROM users
LEFT JOIN orders
ON users.id=orders.user_id;</code></pre></div>
        <div class="guide-block"><h4>RIGHT JOIN</h4><pre><code>SELECT *
FROM users
RIGHT JOIN orders
ON users.id=orders.user_id;</code></pre></div>
      </section>

      <section class="guide-section">
        <h3>Indexes</h3>
        <pre><code>CREATE INDEX idx_name ON users(name);
DROP INDEX idx_name ON users;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Views</h3>
        <pre><code>CREATE VIEW active_users AS
SELECT * FROM users WHERE status='active';

SELECT * FROM active_users;

DROP VIEW active_users;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Transactions</h3>
        <pre><code>START TRANSACTION;
COMMIT;
ROLLBACK;</code></pre>
      </section>

      <section class="guide-section">
        <h3>User Management</h3>
        <pre><code>SELECT user,host FROM mysql.user;

CREATE USER 'nabeel'@'localhost'
IDENTIFIED BY 'Password123';

ALTER USER 'nabeel'@'localhost'
IDENTIFIED BY 'NewPassword';

DROP USER 'nabeel'@'localhost';</code></pre>
      </section>

      <section class="guide-section">
        <h3>Permissions</h3>
        <pre><code>GRANT ALL PRIVILEGES ON *.* TO 'nabeel'@'localhost';
GRANT ALL PRIVILEGES ON school.* TO 'nabeel'@'localhost';
GRANT SELECT ON school.* TO 'nabeel'@'localhost';
REVOKE ALL PRIVILEGES ON school.* FROM 'nabeel'@'localhost';
FLUSH PRIVILEGES;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Backup &amp; Import</h3>
        <pre><code># Export
mysqldump -u root -p database_name > backup.sql

# Import
mysql -u root -p database_name < backup.sql</code></pre>
      </section>

      <section class="guide-section">
        <h3>Information Commands</h3>
        <pre><code>SELECT VERSION();
SELECT USER();
SELECT DATABASE();
SELECT NOW();
SHOW VARIABLES;
SHOW STATUS;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Search Database Objects</h3>
        <pre><code>SHOW TABLES;
SHOW COLUMNS FROM users;
SHOW INDEX FROM users;
SHOW TRIGGERS;
SHOW EVENTS;
SHOW PROCEDURE STATUS;
SHOW FUNCTION STATUS;</code></pre>
      </section>

      <section class="guide-section">
        <h3>Advanced Commands</h3>
        <div class="guide-block"><h4>Create Trigger</h4><pre><code>CREATE TRIGGER log_insert
AFTER INSERT ON users
FOR EACH ROW
INSERT INTO logs(action)
VALUES('User Added');</code></pre></div>
        <div class="guide-block"><h4>Create Event</h4><pre><code>CREATE EVENT delete_logs
ON SCHEDULE EVERY 1 DAY
DO
DELETE FROM logs
WHERE created_at < NOW() - INTERVAL 30 DAY;</code></pre></div>
        <div class="guide-block"><h4>Create Stored Procedure</h4><pre><code>DELIMITER //

CREATE PROCEDURE GetUsers()
BEGIN
SELECT * FROM users;
END//

DELIMITER ;

CALL GetUsers();</code></pre></div>
        <div class="guide-block"><h4>Create Function</h4><pre><code>CREATE FUNCTION add_numbers(a INT,b INT)
RETURNS INT
RETURN a+b;

SELECT add_numbers(5,10);</code></pre></div>
      </section>

      <section class="guide-section">
        <h3>Most Used Commands Daily</h3>
        <pre><code>SHOW DATABASES;
USE database_name;
SHOW TABLES;
DESC table_name;
SELECT * FROM table_name;
INSERT INTO table_name VALUES(...);
UPDATE table_name SET ...;
DELETE FROM table_name WHERE ...;
CREATE DATABASE database_name;
CREATE TABLE table_name (...);
ALTER TABLE table_name ...;
DROP TABLE table_name;
DROP DATABASE database_name;
CREATE USER ...;
GRANT ALL PRIVILEGES ...;
FLUSH PRIVILEGES;</code></pre>
      </section>
    </div>
  </div>
</div>
