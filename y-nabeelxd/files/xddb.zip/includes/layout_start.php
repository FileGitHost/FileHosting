<?php
$flash = get_flash();
$server_info = get_server_info($conn);
$page = isset($edit_row) ? 'edit' : ($active_tab);
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SQL Management<?= $selected_db ? ' · ' . esc($selected_db) : '' ?><?= $selected_table ? ' · ' . esc($selected_table) : '' ?></title>
  <link rel="stylesheet" href="assets/css/theme.css">
</head>
<body>
<div class="app-shell">
  <header class="app-header">
    <div class="header-left">
      <div class="app-logo">DB</div>
      <div>
        <div class="app-title">SQL Management</div>
        <div class="breadcrumb">
          <a href="<?= esc(base_url(['tab' => 'databases'])) ?>">Server</a>
          <?php if ($selected_db): ?>
            <span>›</span><a href="<?= esc(base_url(['db' => $selected_db, 'tab' => 'structure'])) ?>"><?= esc($selected_db) ?></a>
          <?php endif; ?>
          <?php if ($selected_table): ?>
            <span>›</span><span><?= esc($selected_table) ?></span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="header-right">
      <span class="server-badge"><?= esc($user) ?>@<?= esc($host) ?>:<?= esc($port) ?></span>
      <button type="button" class="btn btn-secondary btn-sm guide-btn" id="openGuideBtn" title="SQL Reference Guide">📖 Guide</button>
      <button class="btn-icon theme-toggle-btn" title="Switch theme">☀️</button>
      <a href="logout.php" class="btn btn-danger btn-sm">Disconnect</a>
    </div>
  </header>
  <div class="app-body">
    <aside class="sidebar">
      <div class="sidebar-header">
        <input type="text" id="sidebarSearch" class="sidebar-search" placeholder="Filter databases...">
      </div>
      <div class="sidebar-section" id="sidebarSection">
        <?php if (!empty($_SESSION['favorites'])): ?>
          <div class="sidebar-label">Favorites</div>
          <?php foreach ($_SESSION['favorites'] as $fav): ?>
            <?= render_sidebar_db_group($fav, $tables_by_db[$fav] ?? [], $selected_db, $selected_table, '★') ?>
          <?php endforeach; ?>
        <?php endif; ?>
        <?php if (!empty($_SESSION['recent'])): ?>
          <div class="sidebar-label">Recent</div>
          <?php foreach ($_SESSION['recent'] as $rec): ?>
            <?= render_sidebar_db_group($rec, $tables_by_db[$rec] ?? [], $selected_db, $selected_table, '⏱', true, $active_tab) ?>
          <?php endforeach; ?>
        <?php endif; ?>
        <div class="sidebar-label">Databases (<?= count($databases) ?>)</div>
        <?php foreach ($databases as $dbitem): ?>
          <?= render_sidebar_db_group($dbitem, $tables_by_db[$dbitem] ?? [], $selected_db, $selected_table) ?>
        <?php endforeach; ?>
      </div>
      <div class="sidebar-actions">
        <a href="<?= esc(base_url(['tab' => 'databases'])) ?>" class="btn btn-secondary btn-sm" style="flex:1">+ New DB</a>
      </div>
    </aside>
    <main class="main-content">
      <?= nav_tabs($level, $selected_db, $selected_table, $active_tab) ?>
      <div class="content-area">
        <?php if ($flash): ?>
          <div class="alert alert-<?= $flash['type'] === 'error' ? 'error' : 'success' ?>"><?= esc($flash['message']) ?></div>
        <?php endif; ?>
