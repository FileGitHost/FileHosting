      </div>
    </main>
  </div>
  <?php require __DIR__ . '/sql_guide.php'; ?>
  <footer class="app-footer">Powered by <strong>TeamXD</strong> · created by <strong>Nabeel XD</strong></footer>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
