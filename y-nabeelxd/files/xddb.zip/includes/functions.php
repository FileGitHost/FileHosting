<?php

function esc($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function base_url($params = []) {
    $query = http_build_query($params);
    return 'dashboard.php' . ($query ? '?' . $query : '');
}

function get_databases($conn) {
    $list = [];
    $result = $conn->query('SHOW DATABASES');
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $list[] = $row['Database'];
        }
    }
    return $list;
}

function get_tables($conn, $db) {
    $list = [];
    $conn->select_db($db);
    $result = $conn->query('SHOW TABLES');
    if ($result) {
        while ($row = $result->fetch_row()) {
            $list[] = $row[0];
        }
    }
    return $list;
}

function get_table_structure($conn, $db, $table) {
    $conn->select_db($db);
    $columns = [];
    $result = $conn->query("SHOW FULL COLUMNS FROM `$table`");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $columns[] = $row;
        }
    }
    return $columns;
}

function get_table_indexes($conn, $db, $table) {
    $conn->select_db($db);
    $indexes = [];
    $result = $conn->query("SHOW INDEX FROM `$table`");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $indexes[] = $row;
        }
    }
    return $indexes;
}

function get_table_status($conn, $db, $table) {
    $conn->select_db($db);
    $result = $conn->query("SHOW TABLE STATUS LIKE '" . $conn->real_escape_string($table) . "'");
    if ($result) {
        return $result->fetch_assoc();
    }
    return null;
}

function get_db_size($conn, $db) {
    $conn->select_db($db);
    $result = $conn->query("SELECT SUM(data_length + index_length) AS size FROM information_schema.TABLES WHERE table_schema = '" . $conn->real_escape_string($db) . "'");
    if ($result) {
        $row = $result->fetch_assoc();
        return (int)($row['size'] ?? 0);
    }
    return 0;
}

function format_bytes($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GiB';
    }
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MiB';
    }
    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KiB';
    }
    return $bytes . ' B';
}

function run_query($conn, $sql) {
    $result = $conn->query($sql);
    return [
        'success' => $result !== false,
        'result' => $result,
        'error' => $conn->error,
        'affected' => $conn->affected_rows,
        'insert_id' => $conn->insert_id
    ];
}

function add_query_history($sql) {
    if (!isset($_SESSION['query_history'])) {
        $_SESSION['query_history'] = [];
    }
    array_unshift($_SESSION['query_history'], [
        'sql' => $sql,
        'time' => date('Y-m-d H:i:s')
    ]);
    $_SESSION['query_history'] = array_slice($_SESSION['query_history'], 0, 50);
}

function get_primary_key($conn, $db, $table) {
    $indexes = get_table_indexes($conn, $db, $table);
    foreach ($indexes as $idx) {
        if ($idx['Key_name'] === 'PRIMARY') {
            return $idx['Column_name'];
        }
    }
    $columns = get_table_structure($conn, $db, $table);
    return $columns[0]['Field'] ?? null;
}

function build_where_from_pk($conn, $db, $table, $pk_values) {
    $pk = get_primary_key($conn, $db, $table);
    if (!$pk || !isset($pk_values[$pk])) {
        return null;
    }
    $conn->select_db($db);
    $val = $conn->real_escape_string($pk_values[$pk]);
    return "`$pk` = '$val'";
}

function export_sql($conn, $db, $tables = null) {
    $conn->select_db($db);
    if ($tables === null) {
        $tables = get_tables($conn, $db);
    }
    $output = "-- SQL Export\n-- Database: $db\n-- Date: " . date('Y-m-d H:i:s') . "\n\n";
    $output .= "CREATE DATABASE IF NOT EXISTS `$db`;\nUSE `$db`;\n\n";
    foreach ($tables as $table) {
        $create = $conn->query("SHOW CREATE TABLE `$table`");
        if ($create) {
            $row = $create->fetch_assoc();
            $output .= "DROP TABLE IF EXISTS `$table`;\n";
            $output .= $row['Create Table'] . ";\n\n";
        }
        $data = $conn->query("SELECT * FROM `$table`");
        if ($data && $data->num_rows > 0) {
            $columns = [];
            while ($field = $data->fetch_field()) {
                $columns[] = "`" . $field->name . "`";
            }
            $data->data_seek(0);
            while ($row = $data->fetch_assoc()) {
                $values = [];
                foreach ($row as $val) {
                    if ($val === null) {
                        $values[] = 'NULL';
                    } else {
                        $values[] = "'" . $conn->real_escape_string($val) . "'";
                    }
                }
                $output .= "INSERT INTO `$table` (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $values) . ");\n";
            }
            $output .= "\n";
        }
    }
    return $output;
}

function export_csv($conn, $db, $table) {
    $conn->select_db($db);
    $result = $conn->query("SELECT * FROM `$table`");
    $output = fopen('php://temp', 'r+');
    if ($result && $result->num_rows > 0) {
        $headers = [];
        while ($field = $result->fetch_field()) {
            $headers[] = $field->name;
        }
        fputcsv($output, $headers);
        $result->data_seek(0);
        while ($row = $result->fetch_assoc()) {
            fputcsv($output, $row);
        }
    }
    rewind($output);
    $csv = stream_get_contents($output);
    fclose($output);
    return $csv;
}

function export_json($conn, $db, $table) {
    $conn->select_db($db);
    $result = $conn->query("SELECT * FROM `$table`");
    $rows = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
    }
    return json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

function export_xml($conn, $db, $table) {
    $conn->select_db($db);
    $result = $conn->query("SELECT * FROM `$table`");
    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= "<database name=\"" . esc($db) . "\">\n";
    $xml .= "  <table name=\"" . esc($table) . "\">\n";
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $xml .= "    <row>\n";
            foreach ($row as $key => $val) {
                $xml .= "      <" . esc($key) . ">" . esc($val ?? '') . "</" . esc($key) . ">\n";
            }
            $xml .= "    </row>\n";
        }
    }
    $xml .= "  </table>\n</database>";
    return $xml;
}

function get_server_info($conn) {
    return [
        'version' => $conn->server_info,
        'host' => $conn->host_info,
        'protocol' => $conn->protocol_version,
        'charset' => $conn->character_set_name()
    ];
}

function get_server_status($conn) {
    $status = [];
    $result = $conn->query('SHOW GLOBAL STATUS');
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $status[$row['Variable_name']] = $row['Value'];
        }
    }
    return $status;
}

function get_server_variables($conn) {
    $vars = [];
    $result = $conn->query('SHOW GLOBAL VARIABLES');
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $vars[$row['Variable_name']] = $row['Value'];
        }
    }
    return $vars;
}

function get_users($conn) {
    $users = [];
    $result = $conn->query("SELECT User, Host FROM mysql.user ORDER BY User, Host");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }
    return $users;
}

function get_user_grants($conn, $user, $host) {
    $grants = [];
    $user_esc = $conn->real_escape_string($user);
    $host_esc = $conn->real_escape_string($host);
    $result = $conn->query("SHOW GRANTS FOR '$user_esc'@'$host_esc'");
    if ($result) {
        while ($row = $result->fetch_row()) {
            $grants[] = $row[0];
        }
    }
    return $grants;
}

function get_triggers($conn, $db, $table = null) {
    $conn->select_db($db);
    $triggers = [];
    if ($table) {
        $result = $conn->query("SHOW TRIGGERS LIKE '" . $conn->real_escape_string($table) . "'");
    } else {
        $result = $conn->query('SHOW TRIGGERS');
    }
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $triggers[] = $row;
        }
    }
    return $triggers;
}

function get_events($conn, $db) {
    $conn->select_db($db);
    $events = [];
    $result = $conn->query('SHOW EVENTS');
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
    }
    return $events;
}

function get_routines($conn, $db) {
    $conn->select_db($db);
    $routines = [];
    $result = $conn->query("SELECT ROUTINE_NAME, ROUTINE_TYPE, DTD_IDENTIFIER FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = '" . $conn->real_escape_string($db) . "'");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $routines[] = $row;
        }
    }
    return $routines;
}

function get_views($conn, $db) {
    $conn->select_db($db);
    $views = [];
    $result = $conn->query("SHOW FULL TABLES WHERE Table_type = 'VIEW'");
    if ($result) {
        while ($row = $result->fetch_row()) {
            $views[] = $row[0];
        }
    }
    return $views;
}

function render_result_table($result) {
    if (!$result instanceof mysqli_result) {
        return '';
    }
    $html = '<div class="table-wrap"><table class="data-table"><thead><tr>';
    $fields = $result->fetch_fields();
    foreach ($fields as $field) {
        $html .= '<th>' . esc($field->name) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    while ($row = $result->fetch_assoc()) {
        $html .= '<tr>';
        foreach ($row as $value) {
            $html .= '<td>' . ($value === null ? '<span class="null-val">NULL</span>' : esc($value)) . '</td>';
        }
        $html .= '</tr>';
    }
    $html .= '</tbody></table></div>';
    return $html;
}

function flash_message($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function render_sidebar_db_group($dbitem, $tables, $selected_db, $selected_table, $icon = '📁', $removable = false, $active_tab = '') {
    $is_active = $selected_db === $dbitem;
    $is_expanded = $is_active;
    $table_count = count($tables);
    $html = '<div class="sidebar-db-group' . ($is_expanded ? ' expanded' : '') . '" data-db="' . esc($dbitem) . '">';
    $html .= '<div class="sidebar-db-row">';
    $html .= '<button type="button" class="sidebar-toggle" title="Expand / collapse tables" aria-expanded="' . ($is_expanded ? 'true' : 'false') . '">';
    $html .= '<span class="toggle-icon">' . ($is_expanded ? '▼' : '▶') . '</span></button>';
    $html .= '<a href="' . esc(base_url(['db' => $dbitem, 'tab' => 'structure'])) . '" class="sidebar-item db-link' . ($is_active ? ' active' : '') . '" data-name="' . esc($dbitem) . '">';
    $html .= '<span class="icon">' . $icon . '</span><span class="db-name">' . esc($dbitem) . '</span>';
    if ($table_count) {
        $html .= '<span class="table-count">' . $table_count . '</span>';
    }
    $html .= '</a>';
    if ($removable) {
        $html .= '<form method="POST" action="actions.php" class="sidebar-remove-form">';
        $html .= '<input type="hidden" name="action" value="remove_recent">';
        $html .= '<input type="hidden" name="recent_db" value="' . esc($dbitem) . '">';
        if ($selected_db) {
            $html .= '<input type="hidden" name="db" value="' . esc($selected_db) . '">';
        }
        if ($selected_table) {
            $html .= '<input type="hidden" name="table" value="' . esc($selected_table) . '">';
        }
        if ($active_tab) {
            $html .= '<input type="hidden" name="tab" value="' . esc($active_tab) . '">';
        }
        $html .= '<button type="submit" class="sidebar-remove-recent" title="Remove from recent" aria-label="Remove from recent">×</button>';
        $html .= '</form>';
    }
    if ($table_count) {
        $html .= '<div class="sidebar-scroll-btns">';
        $html .= '<button type="button" class="sidebar-scroll-btn sidebar-scroll-up" title="Scroll up">▲</button>';
        $html .= '<button type="button" class="sidebar-scroll-btn sidebar-scroll-down" title="Scroll down">▼</button>';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="sidebar-table-list' . ($is_expanded ? '' : ' collapsed') . '">';
    foreach ($tables as $titem) {
        $html .= '<a href="' . esc(base_url(['db' => $dbitem, 'table' => $titem, 'tab' => 'browse'])) . '" class="sidebar-item nested' . ($selected_table === $titem && $is_active ? ' active' : '') . '" data-name="' . esc($titem) . '">';
        $html .= '<span class="icon">📋</span>' . esc($titem) . '</a>';
    }
    $html .= '</div></div>';
    return $html;
}

function nav_tabs($level, $db, $table, $active) {
    $tabs = [];
    if ($level === 'server') {
        $tabs = [
            'databases' => 'Databases',
            'sql' => 'SQL',
            'status' => 'Status',
            'variables' => 'Variables',
            'users' => 'User accounts',
            'export' => 'Export',
            'import' => 'Import',
            'history' => 'Query history'
        ];
    } elseif ($level === 'database') {
        $tabs = [
            'structure' => 'Structure',
            'sql' => 'SQL',
            'search' => 'Search',
            'export' => 'Export',
            'import' => 'Import',
            'operations' => 'Operations',
            'routines' => 'Routines',
            'events' => 'Events',
            'triggers' => 'Triggers',
            'designer' => 'Designer'
        ];
    } elseif ($level === 'table') {
        $tabs = [
            'browse' => 'Browse',
            'structure' => 'Structure',
            'sql' => 'SQL',
            'search' => 'Search',
            'insert' => 'Insert',
            'export' => 'Export',
            'import' => 'Import',
            'operations' => 'Operations',
            'triggers' => 'Triggers',
            'indexes' => 'Indexes'
        ];
    }
    $html = '<nav class="tab-nav">';
    foreach ($tabs as $key => $label) {
        $params = ['tab' => $key];
        if ($db) $params['db'] = $db;
        if ($table) $params['table'] = $table;
        $class = $active === $key ? 'tab-link active' : 'tab-link';
        $html .= '<a href="' . esc(base_url($params)) . '" class="' . $class . '">' . esc($label) . '</a>';
    }
    $html .= '</nav>';
    return $html;
}
